﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


namespace Online_Pizza.UserMaster
{
    public partial class User : System.Web.UI.MasterPage
    {
        //SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\asp.net\Online Pizza\Online Pizza\App_Data\pizzadata.mdf;Integrated Security=True");
        //SqlCommand cmd;
        //SqlDataAdapter da = new SqlDataAdapter();
        //DataTable dt = new DataTable();

        protected void Page_Load(object sender, EventArgs e)
        {
           // con.Open();
        }


    }
}